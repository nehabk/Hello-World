package com.flp.ems.domain;

import java.sql.Date;

//import java.sql.Date;

public class Employee {
	
	int Phone_no, dept, proj, roles;
	String name, Email_id, Address, Kin_Id;
	Date dob, doj;
	
	public int getDept() {
		return dept;
	}

	public void setDept(int dept) {
		this.dept = dept;
	}

	public int getProj() {
		return proj;
	}

	public void setProj(int proj) {
		this.proj = proj;
	}

	public int getRoles() {
		return roles;
	}

	public void setRoles(int roles) {
		this.roles = roles;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail_id() {
		return Email_id;
	}

	public void setEmail_id(String email_id) {
		Email_id = email_id;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getKin_Id() {
		return Kin_Id;
	}

	public void setKin_Id(String kin_Id) {
		Kin_Id = kin_Id;
	}

	public int getPhone_no() {
		return Phone_no;
	}

	public void setPhone_no(int phone_no) {
		Phone_no = phone_no;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if(this.Kin_Id == ((Employee)obj).Kin_Id){
			return true;
		}
		
		else{
			return false;
		}
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String s = "Name: " + this.getName() + 
					"\nKin_ID: " + this.getKin_Id() + 
					"\nEmail ID: " + this.getEmail_id() + 
					"\nDepartment: " + this.getDept() + 
					"\nProject: " + this.getProj() + 
					"\nRole: " + this.getRoles();
		
		return s;
	}
	
}
