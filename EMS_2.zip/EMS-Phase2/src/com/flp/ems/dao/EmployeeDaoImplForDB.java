package com.flp.ems.dao;
import com.flp.ems.domain.Department;
import com.flp.ems.domain.Employee;
import com.flp.ems.domain.Project;
import com.flp.ems.domain.Role;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class EmployeeDaoImplForDB implements IemployeeDao, Cloneable{

	//static HashMap<String, Employee>h = new HashMap<>();
	Connection dbConnection;
	
	public void connect() throws SQLException{
		dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");

	}
	
	public List<Department> RetrieveDept() throws SQLException{
		List<Department> lDept = new ArrayList<>();
		Statement stmt = null;
		
		try{
			stmt = dbConnection.createStatement();
			String selectQuery = "select * from Department";
			
			ResultSet result = stmt.executeQuery(selectQuery);
			
			while(result.next()){
				Department d = new Department();
				d.setDID(result.getInt("DID"));
				d.setDName(result.getString("DName"));
				
				lDept.add(d);
			} 
		}finally {
	        if (stmt != null) { stmt.close(); }
	    }
		
		return lDept;
		
	}
	
	public List<Project> RetrieveProject() throws SQLException{
		List<Project> lProject = new ArrayList<>();
		Statement stmt = null;
		
		try{
			stmt = dbConnection.createStatement();
			String selectQuery = "select * from Project";
			
			ResultSet result = stmt.executeQuery(selectQuery);
			
			while(result.next()){
				Project p = new Project();
				p.setPID(result.getInt("PID"));
				p.setPName(result.getString("DName"));
				
				lProject.add(p);
			} 
		}finally {
	        if (stmt != null) { stmt.close(); }
	    }
		
		return lProject;
		
	}
	
	public List<Role> RetrieveRole() throws SQLException{
		List<Role> lRole = new ArrayList<>();
		Statement stmt = null;
		
		try{
			stmt = dbConnection.createStatement();
			String selectQuery = "select * from Role";
			
			ResultSet result = stmt.executeQuery(selectQuery);
			
			while(result.next()){
				Role r = new Role();
				r.setRID(result.getInt("RID"));
				r.setRName(result.getString("RName"));
				
				lRole.add(r);
			} 
		}finally {
	        if (stmt != null) { stmt.close(); }
	    }
		
		return lRole;
		
	}
	
	@Override
	public boolean AddEmployee(Employee e) {
		// TODO Auto-generated method stub
		
		/*if(h.get(e.getKin_Id()) != null){
			return false;
		}
		
		else{
			h.put(e.getKin_Id(), e);
			return true;
		}*/
		
		Statement stmt = null;		

		try{
			stmt = dbConnection.prepareStatement("select DID from Department where DName = ?");
			
			ResultSet result = stmt.executeQuery("select DID from Department where DName = );
			
			while(result.next()){
				Role r = new Role();
				r.setRID(result.getInt("RID"));
				r.setRName(result.getString("RName"));
				
				lRole.add(r);
			} 
		}finally {
	        if (stmt != null) { stmt.close(); }
	    }
	}

	@Override
	public boolean ModifyEmployee(Employee e) {
		// TODO Auto-generated method stub
		if(h.get(e.getKin_Id()) == null){
			return false;
		}
		
		else{
			h.put(e.getKin_Id(), e);
			return true;
		}	
	}
	

	@Override
	public boolean RemoveEmployee(String id) {
		// TODO Auto-generated method stub
		if(h.get(id) == null){
			return false;
		}
		
		else{
			h.remove(id);
			return true;
		}
	}

	@Override
	public Employee SearchEmployee(String id) {
		// TODO Auto-generated method stub
		System.out.println("In dao search");
		Employee e =  h.get(id);
		//System.out.println(e.getName());
		return e;
	}

	@Override
	public HashMap<String, Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		HashMap<String, Employee> h2=(HashMap<String, Employee>)h.clone();
		return h2;
	}

}
