package com.flp.ems.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;

public class Validate {
	
	public boolean validateName(String name){
		String regex = "[A-Za-z ]+";
		
		if(name.matches(regex)){
			return true;
		}
		
		else{
			return false;
		}
	}
	
	public boolean validateEmail(String email_id){
		String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		
		if(email_id.matches(regex)){
			return true;
		}
		
		else{
			return false;
		}
	}
	

	public boolean validateDate(String input) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

	     try {
	          format.parse(input);
	          return true;
	     }
	     catch(ParseException e){
	          return false;
	     }
	}


}
