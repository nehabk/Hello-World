package com.flp.ems.dao;

import java.util.List;

import com.flp.ems.domain.Employee;

public interface IEmployeeDao {
	boolean AddEmployee(Employee emp);
	boolean ModifyEmployee(Employee e);
	boolean RemoveEmployee(String id);
	Employee SearchEmployee(String id);
	List<Employee> getAllEmployee();
}
