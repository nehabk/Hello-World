package com.flp.ems.domain;

public class Project {
	int PID;
	String PName;
	
	public int getPID() {
		return PID;
	}
	public void setPID(int pID) {
		PID = pID;
	}
	public String getPName() {
		return PName;
	}
	public void setPName(String pName) {
		PName = pName;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String s = this.getPID() + ". " + this.getPName();
		
		return s;
	}


}
