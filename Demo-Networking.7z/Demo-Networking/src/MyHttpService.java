import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class MyHttpService {

	public static void main(String[] args) throws IOException {
		int port=400;
		ServerSocket service=new ServerSocket(port);
  System.out.println("waiting for a connection");
  Socket clientinfo=service.accept();
  System.out.println("Client info starts:");
  System.out.println(clientinfo);
  System.out.println("end :)");
  InputStream in=clientinfo.getInputStream();
  InputStreamReader bridge=new InputStreamReader(in);
  BufferedReader bReader =new BufferedReader(bridge);
  //int i=1
  while(true)
  {
	  String line=bReader.readLine();
	  if(line.isEmpty())
	  {
		  break;
	  }
	  System.out.println(line);
  }
  //String s="Hello!world";
  OutputStream out=clientinfo.getOutputStream();
 // OutputStreamWriter bridge1=new OutputStreamWriter(out); 
  PrintWriter bWriter =new PrintWriter(out);
 bWriter.println("Hello! World");
 bWriter.println("Hello! World");
  bWriter.flush();
  bWriter.close();
  //System.out.println();
  service.close();       
  
	}

}

