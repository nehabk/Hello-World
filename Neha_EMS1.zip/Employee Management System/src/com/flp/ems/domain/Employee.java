package com.flp.ems.domain;


//import java.sql.Date;

public class Employee {
	
	String name, Email_id, Address, Kin_Id;
	String Phone_no;
	String dob, doj;
	
	public Employee(String name, String email_id, String address, String kin_Id, String phone_no, String dob, String doj) {
		this.name = name;
		Email_id = email_id;
		Address = address;
		Kin_Id = kin_Id;
		Phone_no = phone_no;
		this.dob = dob;
		this.doj = doj;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail_id() {
		return Email_id;
	}

	public void setEmail_id(String email_id) {
		Email_id = email_id;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getKin_Id() {
		return Kin_Id;
	}

	public void setKin_Id(String kin_Id) {
		Kin_Id = kin_Id;
	}

	public String getPhone_no() {
		return Phone_no;
	}

	public void setPhone_no(String phone_no) {
		Phone_no = phone_no;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public String getDoj() {
		return doj;
	}

	public void setDoj(String doj) {
		this.doj = doj;
	}
	
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if(this.Kin_Id == ((Employee)obj).Kin_Id){
			return true;
		}
		
		else{
			return false;
		}
	}
	
}
