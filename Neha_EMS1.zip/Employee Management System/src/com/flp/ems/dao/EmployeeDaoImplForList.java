package com.flp.ems.dao;
import com.flp.ems.domain.Employee;

import java.util.*;

public class EmployeeDaoImplForList implements IemployeeDao, Cloneable{

	static HashMap<String, Employee>h = new HashMap<>();
	
	@Override
	public boolean AddEmployee(Employee e) {
		// TODO Auto-generated method stub
		
		if(h.get(e.getKin_Id()) != null){
			return false;
		}
		
		else{
			h.put(e.getKin_Id(), e);
			return true;
		}
	}

	@Override
	public boolean ModifyEmployee(Employee e) {
		// TODO Auto-generated method stub
		if(h.get(e.getKin_Id()) == null){
			return false;
		}
		
		else{
			h.put(e.getKin_Id(), e);
			return true;
		}	
	}
	

	@Override
	public boolean RemoveEmployee(String id) {
		// TODO Auto-generated method stub
		if(h.get(id) == null){
			return false;
		}
		
		else{
			h.remove(id);
			return true;
		}
	}

	@Override
	public Employee SearchEmployee(String id) {
		// TODO Auto-generated method stub
		System.out.println("In dao search");
		Employee e =  h.get(id);
		//System.out.println(e.getName());
		return e;
	}

	@Override
	public HashMap<String, Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		HashMap<String, Employee> h2=(HashMap<String, Employee>)h.clone();
		return h2;
	}

}
