package com.flp.ems.service;

import java.util.HashMap;

public interface IEmployeeService {

	boolean AddEmployee(HashMap<String, String> hm);
	boolean ModifyEmployee(HashMap<String, String> hm);
	boolean RemoveEmployee(String id);
	HashMap<String, String> SearchEmployee(String id);
	HashMap<Integer, HashMap<String, String>> getAllEmployee();
}
