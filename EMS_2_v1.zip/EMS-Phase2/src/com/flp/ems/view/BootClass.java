package com.flp.ems.view;

import java.util.Scanner;

public class BootClass {
	
	void menuSelection(){
		Scanner sc = new Scanner(System.in);
		UserInteraction u = new UserInteraction();
		int ans;
		
		do{
			System.out.println("\n1Add Employee \n2.Modify Employee \n3.Remove Employee \n4.Search Employee \n5.View Employee");
			System.out.println("\nEnter your choice: ");
			int ch = sc.nextInt();
			sc.nextLine();
			
			switch(ch){
			case 1:
				u.AddEmployee(0);
				break;
				
			case 2:
				u.ModifyEmployee();
				break;
				
			case 3:
				u.RemoveEmployee();
				break;
				
			case 4:
				u.SearchEmployee();
				break;
				
			case 5:
				u.getAllEmployee();
				break;
			}
			
			System.out.println("\nDo you want to continue?(1/0) ");
			ans = sc.nextInt();
		}while(ans == 1);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new BootClass().menuSelection();

	}

}
