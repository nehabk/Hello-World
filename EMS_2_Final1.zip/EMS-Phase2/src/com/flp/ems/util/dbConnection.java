package com.flp.ems.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.flp.ems.domain.Department;
import com.flp.ems.domain.Project;
import com.flp.ems.domain.Role;

public class dbConnection {
	String sql;

	public List<String> RetrieveDept(){
		List<String> lDept = new ArrayList<>();
		
		sql = "select * from Department";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
			
			try(ResultSet result = stmt.executeQuery(sql)){
				while(result.next()){
					Department d = new Department();
					d.setDID(result.getInt("DID"));
					d.setDName(result.getString("DName"));
					
					lDept.add(d.toString());
				} 
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
		
		return lDept;
		
	}
	
	public List<String> RetrieveProject(String dept){
		List<String> lProject = new ArrayList<>();
		
		//sql = "select p.PID, p.PName from Project p inner join Department d on d.DID=p.Department_id where d.DName=?";
		sql = "select * from Project";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
			
			//stmt.setString(1, dept);
			
			try(ResultSet result = stmt.executeQuery(sql)){
				while(result.next()){
					Project p = new Project();
					p.setPID(result.getInt("PID"));
					p.setPName(result.getString("PName"));
					
					lProject.add(p.toString());
				} 
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
		
		return lProject;
		
	}
	
	public List<String> RetrieveRole(){
		List<String> lRole = new ArrayList<>();
		
		sql = "select * from Role";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
					
			try(ResultSet result = stmt.executeQuery(sql)){
				while(result.next()){
					Role r = new Role();
					r.setRID(result.getInt("RID"));
					r.setRName(result.getString("RName"));
					
					lRole.add(r.toString());
				} 
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}		
		
		
		return lRole;
		
	}
	
	public int getDepartmentId(String name){
		int id = 0;
		sql = "select DID from Department where DName=?";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
			
			stmt.setString(1, name);
			
			try(ResultSet result = stmt.executeQuery()){
				
				while(result.next()){
					id = result.getInt("DID");
					System.out.println("DID: " + id);
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return id;
		
	}
	
	public int getProjectId(String name){
		int id = 0;
		System.out.println("Project name: " + name);
		sql = "select PID from Project where PName=?";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
			
			stmt.setString(1, name);
			
			try(ResultSet result = stmt.executeQuery()){
				System.out.println("Result: "+ result);
				
				while(result.next()){
					id = result.getInt("PID");
					System.out.println("PID: " + id);
				}				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return id;
		
	}
	
	public int getRoleId(String name){
		int id = 0;
		sql = "select RID from Role where RName=?";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
			
			stmt.setString(1, name);
			
			try(ResultSet result = stmt.executeQuery()){
				
				while(result.next()){
					id = result.getInt("RID");
					System.out.println("RID: " + id);
				}				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return id;
		
	}
	
	public String getDepartmentName(int id){
		String name = null;
		
		sql = "select DName from Department where DID=?";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
			
			stmt.setInt(1, id);
			
			try(ResultSet result = stmt.executeQuery()){
				
				while(result.next()){
					name = result.getString("DName");
				}				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return name;
	}
	
	public String getProjectName(int id){
		String name = null;
		
		sql = "select PName from Project where PID=?";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
			
			stmt.setInt(1, id);
			
			try(ResultSet result = stmt.executeQuery()){
				
				while(result.next()){
					name = result.getString("PName");
				}					
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return name;
	}
	
	public String getRoleName(int id){
		String name = null;
		
		sql = "select RName from Role where RID=?";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
			
			stmt.setInt(1, id);
			
			try(ResultSet result = stmt.executeQuery()){
				
				while(result.next()){
					name = result.getString("RName");
				}					
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return name;
	}
}
