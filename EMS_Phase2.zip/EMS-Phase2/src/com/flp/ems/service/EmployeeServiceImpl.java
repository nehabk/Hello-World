package com.flp.ems.service;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.ems.domain.Department;
import com.flp.ems.domain.Employee;
import com.flp.ems.dao.EmployeeDaoImplForDB;

import javax.swing.text.html.HTMLDocument.Iterator;

public class EmployeeServiceImpl implements IEmployeeService{

	String name, Email_id, Address, Kin_Id;
	String Phone_no;
	String dob, doj;
	
	boolean b;
	
	EmployeeDaoImplForDB ed = new EmployeeDaoImplForDB();
	HashMap<Integer, String> dept = new HashMap<>();
	
	public HashMap<Integer, String> RetrieveDept() throws SQLException{
		List<Department> lDept = ed.RetrieveDept();
		
		for(Department d : lDept){
			dept.put(d.getDID(), d.getDName());
		}
		
		return dept;	
	}
	
	public boolean AddEmployee(HashMap<String, String> hm){
		name = hm.get("Name");
		Kin_Id = hm.get("Kin ID");
		Email_id = hm.get("Email ID");
		Phone_no = hm.get("Phone No");
		dob = hm.get("DOB");
		doj = hm.get("DOJ");
		Address = hm.get("Address");
		
		Employee emp = new Employee(name, Email_id, Address, Kin_Id, Phone_no, dob, doj);
		b = new EmployeeDaoImplForDB().AddEmployee(emp);
		return b;
	}
	
	public boolean ModifyEmployee(HashMap<String, String> hm){
		EmployeeDaoImplForDB e1 = new EmployeeDaoImplForDB();
		Employee e = e1.SearchEmployee(hm.get("Kin ID"));
		
		e.setName(hm.get("Name"));
		e.setKin_Id(hm.get("Kin ID"));
		e.setEmail_id(hm.get("Email ID"));
		e.setPhone_no(hm.get("Phone No"));
		e.setDob(hm.get("DOB"));
		e.setDoj(hm.get("DOJ"));
		e.setAddress(hm.get("Address"));
		
		b = e1.ModifyEmployee(e);
		return b;
	}
	public boolean RemoveEmployee(String id){
		b = new EmployeeDaoImplForDB().RemoveEmployee(id);
		return b;
	}
	
	public HashMap<String, String> getEmployee(Employee e){
		HashMap<String, String> hm = new HashMap<>();
		
		hm.put("Name", e.getName());
		hm.put("Kin_ID", e.getKin_Id());
		hm.put("Email_ID", e.getEmail_id());
		hm.put("Phone No", e.getPhone_no());
		hm.put("DOB", e.getDob());
		hm.put("DOJ", e.getDoj());
		hm.put("Address:", e.getAddress());
		
		return hm;
	}
	
	public HashMap<String, String> SearchEmployee(String id){
	
		Employee e = new EmployeeDaoImplForDB().SearchEmployee(id);
		HashMap<String, String> hm = new HashMap<>();
		
		if(e != null){
			hm = this.getEmployee(e);
		}
		
		return hm;
	}
	
	public HashMap<Integer, HashMap<String, String>> getAllEmployee(){
		int cnt = 1;
		HashMap<String, Employee> h = new EmployeeDaoImplForDB().getAllEmployee();
		
		HashMap<Integer, HashMap<String, String>> m = new HashMap<>();
		
		for (Map.Entry<String, Employee> entry : h.entrySet()) {
		    Employee e1 = entry.getValue();
		    
		    HashMap<String,	String> map = this.getEmployee(e1);
		    
		    m.put(cnt, map);
		    cnt++;
		}
		
		return m;
	}

}
