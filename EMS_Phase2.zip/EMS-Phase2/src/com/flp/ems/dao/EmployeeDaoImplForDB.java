package com.flp.ems.dao;
import com.flp.ems.domain.Department;
import com.flp.ems.domain.Employee;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class EmployeeDaoImplForDB implements IemployeeDao, Cloneable{

	static HashMap<String, Employee>h = new HashMap<>();
	List<Department> lDept = new ArrayList<>();
	Connection dbConnection;
	
	public void connect() throws SQLException{
		dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");

	}
	
	public List<Department> RetrieveDept() throws SQLException{
		Statement stmt = null;
		
		try{
			stmt = dbConnection.createStatement();
			String selectQuery = "select * from Department";
			
			ResultSet result = stmt.executeQuery(selectQuery);
			
			while(result.next()){
				Department d = new Department();
				d.setDID(result.getInt("DID"));
				d.setDName(result.getString("DName"));
				
				lDept.add(d);
			} 
		}finally {
	        if (stmt != null) { stmt.close(); }
	    }
		
		return lDept;
		
	}
	
	@Override
	public boolean AddEmployee(Employee e) {
		// TODO Auto-generated method stub
		
		if(h.get(e.getKin_Id()) != null){
			return false;
		}
		
		else{
			h.put(e.getKin_Id(), e);
			return true;
		}
	}

	@Override
	public boolean ModifyEmployee(Employee e) {
		// TODO Auto-generated method stub
		if(h.get(e.getKin_Id()) == null){
			return false;
		}
		
		else{
			h.put(e.getKin_Id(), e);
			return true;
		}	
	}
	

	@Override
	public boolean RemoveEmployee(String id) {
		// TODO Auto-generated method stub
		if(h.get(id) == null){
			return false;
		}
		
		else{
			h.remove(id);
			return true;
		}
	}

	@Override
	public Employee SearchEmployee(String id) {
		// TODO Auto-generated method stub
		System.out.println("In dao search");
		Employee e =  h.get(id);
		//System.out.println(e.getName());
		return e;
	}

	@Override
	public HashMap<String, Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		HashMap<String, Employee> h2=(HashMap<String, Employee>)h.clone();
		return h2;
	}

}
