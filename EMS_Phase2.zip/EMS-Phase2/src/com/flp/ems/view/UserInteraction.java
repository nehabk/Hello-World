package com.flp.ems.view;
import com.flp.ems.domain.Employee;
import com.flp.ems.util.*;
import com.flp.ems.service.EmployeeServiceImpl;

import java.sql.Date;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class UserInteraction {

	String name, Email_id, Address, Kin_Id;
	int Phone_no;
	String dob, doj;
	boolean b1;
	
	HashMap<String, String> hm = new HashMap<>();	
	Scanner sc = new Scanner(System.in);
	
	void AddEmployee(int flag) throws SQLException{
		
		Validate v = new Validate();
		sc.nextLine();
		
		System.out.print("Name: ");
		name = sc.nextLine();
		
		boolean b = v.validateName(name);
		
		if(b==true)
			hm.put("Name", name);
		
		else{
			System.out.println("Please enter a valid name!");
			return;
		}
		
		/*System.out.print("Kin ID: ");
		Kin_Id = sc.nextLine();
		hm.put("Kin ID", Kin_Id);*/
		
		/*System.out.print("Email ID: ");
		Email_id = sc.nextLine();
		b = v.validateEmail(Email_id);
		
		if(b==true)
			hm.put("Email ID", Email_id);
		
		else{
			System.out.println("Please enter a valid Email id!");
			return;
		}
		*/
		
		System.out.print("Phone No: ");
		hm.put("Phone No", sc.nextLine());
		
		System.out.print("Date of Birth: ");
		dob = sc.nextLine();
		b = v.validateDate(dob);
		
		if(b==true)
			hm.put("DOB", dob);
		
		else{
			System.out.println("Please enter a valid date of birth!");
			return;
		}
		
		
		System.out.print("Date of Joining: ");
		doj = sc.nextLine();
		b = v.validateDate(doj);
		
		if(b==true)
			hm.put("DOJ", doj);
		
		else{
			System.out.println("Please enter a valid date of joining!");
			return;
		}
		
		System.out.print("Address: ");
		hm.put("Address", sc.next());
		
		if(flag == 0){
			b1 = new EmployeeServiceImpl().AddEmployee(hm);
			
			if(b1 == true)
				System.out.println("\nEmployee Record Added Successfully!");
			
			else
				System.out.println("\nRecord for Kin ID " + Kin_Id + " already exists in database!");
		}
		
		System.out.println("Enter the Depertment No: ");
		
		HashMap<Integer, String> dept = new EmployeeServiceImpl().RetrieveDept();
		
		for (Map.Entry<Integer, String> entry : dept.entrySet()){
			System.out.print(entry.getKey() + ": ");
			System.out.println(entry.getValue());
		}
		
		
	}
	
	void ModifyEmployee(){
		this.getAllEmployee();
		EmployeeServiceImpl es = new EmployeeServiceImpl();
		
		System.out.print("Enter the Kin ID of the employee to modify: ");
		Kin_Id = sc.next();
		
		hm = es.SearchEmployee(Kin_Id);
		
		if(hm.isEmpty()){
			System.out.println("The record of employee " + Kin_Id + " doesn't exist!");
			System.out.println("Please enter valid Kin ID!!");
		}
		
		else{
			System.out.println("Enter the details: ");
			this.AddEmployee(1);
			
			b1 = es.ModifyEmployee(hm); 
			
			if(b1 == true){
				System.out.println("\nRecord modified successfully!");
			}
			
			else{
				System.out.println("\nFailed to update the record!!");
			}
		}
		

	}
	
	void RemoveEmployee(){
		this.getAllEmployee();
		
		System.out.print("Enter the Kin ID of the employee to remove: ");
		Kin_Id = sc.next();
		
		b1 = new EmployeeServiceImpl().RemoveEmployee(Kin_Id);
		
		if(b1 == true){
			System.out.println("\nRecord removed successfully!");
		}
		
		else{
			System.out.println("\nFailed to remove the record!!");
		}
	}
	
	void SearchEmployee(){
		System.out.print("Enter the Kin ID of the employee to search: ");
		Kin_Id = sc.next();
		
		hm = new EmployeeServiceImpl().SearchEmployee(Kin_Id);
		
		if(hm.isEmpty()){
			System.out.println("Employee record not found!");
		}
		
		for (Map.Entry<String, String> entry : hm.entrySet()) {
		    System.out.print(entry.getKey() + ": ");
		    System.out.println(entry.getValue());
		}

	}
	
	void getAllEmployee(){
		HashMap<Integer, HashMap<String, String>> h = new EmployeeServiceImpl().getAllEmployee();
		
		for (Map.Entry<Integer, HashMap<String, String>> entry : h.entrySet()) {
			System.out.println(entry.getKey() + ".");
			
			for(Map.Entry<String, String> entry1 : entry.getValue().entrySet()){
				System.out.print(entry1.getKey() + ": ");
				System.out.println(entry1.getValue());
			}
		}
	}
}
