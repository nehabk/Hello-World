package com.flp.ems.service;

import java.math.BigInteger;
import java.sql.Date;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.flp.ems.domain.Department;
import com.flp.ems.domain.Employee;
import com.flp.ems.domain.Project;
import com.flp.ems.domain.Role;
import com.flp.ems.util.dbConnection;
import com.flp.ems.dao.EmployeeDaoImplForDB;

import javax.swing.text.html.HTMLDocument.Iterator;

public class EmployeeServiceImpl implements IEmployeeService{

	String name, Email_id, Address, Kin_Id, dept, proj, roles;
	String Phone_no;
	Date dob, doj;
	
	boolean b;
	EmployeeDaoImplForDB ed = new EmployeeDaoImplForDB();
	
	public boolean AddEmployee(HashMap<String, String> hm){
		Employee emp = new Employee();
		
		name = hm.get("Name");
		emp.setName(name);
		
		Kin_Id = hm.get("Kin_ID");
		emp.setKin_Id(Kin_Id);
		
		emp.setEmail_id(name + "@gmail.com");
		
		emp.setPhone_no(Integer.parseInt(hm.get("Phone_No")));
		
		emp.setDob(Date.valueOf(hm.get("DOB")));
		emp.setDoj(Date.valueOf(hm.get("DOJ")));
		
		emp.setAddress(hm.get("Address"));
		
		dept = hm.get("Department");
		emp.setDept(new dbConnection().getDepartmentId(dept));
		
		proj = hm.get("Project");
		System.out.println("Project in service: " + proj);
		emp.setProj(new dbConnection().getProjectId(proj));
		
		roles = hm.get("Role");
		emp.setRoles(new dbConnection().getRoleId(roles));
		
		b = new EmployeeDaoImplForDB().AddEmployee(emp);
		return b;
	}
	
	public boolean ModifyEmployee(HashMap<String, String> hm){
		
		//Employee e = ed.SearchEmployee(hm.get("Kin ID"));
		
		Employee e = new Employee();
		
		e.setName(hm.get("Name"));
		e.setKin_Id(hm.get("Kin ID"));
		e.setPhone_no(Integer.parseInt(hm.get("Phone No")));
		e.setDob(Date.valueOf(hm.get("DOB")));
		e.setDoj(Date.valueOf(hm.get("DOJ")));
		e.setAddress(hm.get("Address"));
		
		b = ed.ModifyEmployee(e);
		return b;
	}
	public boolean RemoveEmployee(String id){
		b = new EmployeeDaoImplForDB().RemoveEmployee(id);
		return b;
	}
	
	public HashMap<String, String> getEmployee(Employee e){
		dbConnection d = new dbConnection();
		HashMap<String, String> hm = new HashMap<>();
		
		hm.put("Name", e.getName());
		hm.put("Kin_ID", e.getKin_Id());
		hm.put("Email_ID", e.getEmail_id());
		hm.put("Department", d.getDepartmentName(e.getDept()));
		hm.put("Project", d.getProjectName(e.getProj()));
		hm.put("Role", d.getRoleName(e.getRoles()));
		
		return hm;
	}
	
	public HashMap<String, String> SearchEmployee(String id){
	
		Employee e = ed.SearchEmployee(id);
		HashMap hm = new HashMap<>();
		
		if(e != null){
			hm = this.getEmployee(e);
		}
		
		return hm;
	}
	
	public HashMap<Integer, HashMap<String, String>> getAllEmployee(){
		
		int cnt = 1;
		List<Employee> h = ed.getAllEmployee();
		
		HashMap<Integer, HashMap<String, String>> m = new HashMap<>();
		
		for(Employee e : h){
			HashMap<String,	String> map = this.getEmployee(e);    
		    m.put(cnt, map);
		    cnt++;
		}
		
		/*for (Map.Entry<String, Employee> entry : h.entrySet()) {
		    Employee e1 = entry.getValue();
		    
		    HashMap<String,	String> map = this.getEmployee(e1);
		    
		    m.put(cnt, map);
		    cnt++;
		}
		*/
		return m;
	}

}

