package com.flp.ems.dao;
import com.flp.ems.domain.Department;
import com.flp.ems.domain.Employee;
import com.flp.ems.domain.Project;
import com.flp.ems.domain.Role;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

public class EmployeeDaoImplForDB implements IEmployeeDao, Cloneable{

	//static HashMap<String, Employee>h = new HashMap<>();
	Connection dbConnection;
	String sql = "";
	PreparedStatement stmt;
	
	public EmployeeDaoImplForDB(){
		try {
			dbConnection = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
			stmt = dbConnection.prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	@Override
	public boolean AddEmployee(Employee e) {
		int count = 0;
		sql = "insert into Employee(EName, Kin_id, Email_id, Phone_no, DOB, DOJ, Address, Department_id, Project_id, Role_id) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
			PreparedStatement stmt = dbConn.prepareStatement(sql)){
			
			stmt.setString(1, e.getName());
			stmt.setString(2, e.getKin_Id());
			stmt.setString(3, e.getEmail_id());
			stmt.setInt(4, e.getPhone_no());
			stmt.setDate(5, e.getDob());
			stmt.setDate(6, e.getDoj());
			stmt.setString(7, e.getAddress());
			stmt.setInt(8, e.getDept());
			stmt.setInt(9, e.getProj());
			stmt.setInt(10, e.getRoles());
		
			count = stmt.executeUpdate();
			
		} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
		}
		
		if(count == 0){
			System.out.println("count" + count);
			return false;

		}
		
		else
			return true;
	} 

	@Override
	public boolean ModifyEmployee(Employee e) {
	
		int count = 0;
		
		sql = "update Employee set EName=?, Phone_no=?, DOB=?, DOJ=?, Address=?";
		
		try{
			stmt.setString(1, e.getName());
			stmt.setInt(2, e.getPhone_no());
			stmt.setDate(3, e.getDob());
			stmt.setDate(4, e.getDoj());
			stmt.setString(5, e.getAddress());
			
			count = stmt.executeUpdate();
			
		}catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if(count == 0){
			return false;
		}
		
		else{
			return true;
		}		
		
	}
	

	@Override
	public boolean RemoveEmployee(String id) {
		
		int count = 0;
		
		sql = "delete from Employee where Kin_id=?";
		
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
			stmt.setString(1, id);
			count =stmt.executeUpdate();
		}catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		if(count == 0){
			return false;
		}
		
		else{
			return true;
		}		
				
	}

	@Override
	public Employee SearchEmployee(String id) {
		// TODO Auto-generated method stub
		
		Employee e = new Employee();
		sql = "select * from Employee where Kin_id=?";
		try(Connection dbConn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test");
				PreparedStatement stmt = dbConn.prepareStatement(sql)){
			stmt.setString(1, id);
			
			try(ResultSet rs = stmt.executeQuery()){
				while(rs.next()){
					if(rs != null){
						e.setName(rs.getString("EName"));
						e.setKin_Id(rs.getString("Kin_id"));
						e.setEmail_id(rs.getString("Email_id"));
						e.setDept(rs.getInt("Department_id"));
						e.setProj(rs.getInt("Project_id"));
						e.setRoles(rs.getInt("Role_id"));
					}
				}
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
		return e;

		
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		/*HashMap<String, Employee> h2=(HashMap<String, Employee>)h.clone();
		return h2;*/	
		
		List<Employee> lEmp = new ArrayList<>();
		
		//sql = "select e.EName, e.Kin_id, e.Email_id, d.DName, p.PName, r.RName from Employee e, Department d, Project p, Role r where d.DID = e.Department_id and p.PID=e.Project_id and r.RID=e.Role_id";
		sql = "select EName, Kin_id, Email_id, Department_id, Project_id, Role_id from Employee";
		
		ResultSet result;
		try {
			result = stmt.executeQuery(sql);
			
			if(result != null){
				while(result.next()){
					Employee e = new Employee();
					
					e.setName(result.getString("EName"));
					e.setKin_Id(result.getString("Kin_id"));
					e.setEmail_id(result.getString("Email_id"));
					e.setDept(result.getInt("Department_id"));
					e.setProj(result.getInt("Project_id"));
					e.setRoles(result.getInt("Role_id"));
					
					lEmp.add(e);
				} 
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return lEmp;
		
	}

}
