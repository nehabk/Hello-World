package com.flp.ems.domain;

public class Department {
	int DID;
	String DName;
	
	public int getDID() {
		return DID;
	}
	public void setDID(int dID) {
		DID = dID;
	}
	public String getDName() {
		return DName;
	}
	public void setDName(String dName) {
		DName = dName;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String s = this.getDID() + ". " + this.getDName();
		
		return s;
	}

}
